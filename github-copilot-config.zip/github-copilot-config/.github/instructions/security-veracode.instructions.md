---
name: Security and Veracode instructions
description: Security, CWE, Veracode and secure coding remediation rules
applyTo: '**/*.cs,**/*.ts,**/*.tsx,**/*.js,**/*.jsx,**/*.sql,**/*.config,**/*.json'
---

# Security / Veracode Instructions

## Security First
Treat security findings as production-impacting issues.

Before changing security-sensitive code:
- Understand the data flow.
- Identify the trust boundary.
- Identify the actual vulnerability.
- Prefer the smallest safe remediation.

Do not:
- Disable security checks.
- Suppress findings without justification.
- Remove validation merely to satisfy a scanner.
- Add insecure workarounds.
- Introduce custom cryptography unnecessarily.

## Veracode Workflow
When fixing a Veracode finding:
1. Identify the CWE and affected code.
2. Determine the actual data flow.
3. Identify source -> propagation -> sink.
4. Fix the vulnerability at the appropriate trust boundary.
5. Preserve existing functionality.
6. Add/update focused tests.
7. Avoid unrelated refactoring.

Do not assume a scanner finding is a false positive without examining the code path.

## Common CWE Guidance

### CWE-73 - External Control of File Name or Path
- Do not directly use untrusted input in file paths.
- Validate allowed directories/files.
- Prefer safe path construction.
- Prevent path traversal.
- Validate canonical/normalized paths where appropriate.

### CWE-117 - Improper Output Neutralization for Logs
- Do not write untrusted input directly into logs.
- Prevent log injection/newline manipulation.
- Follow existing structured logging patterns.
- Do not log sensitive data.

### CWE-601 - Open Redirect
- Do not redirect to arbitrary user-controlled URLs.
- Prefer allowlisted destinations.
- Validate redirect targets.

### CWE-90 - LDAP Injection
- Never concatenate untrusted input into LDAP queries.
- Use safe APIs/parameterization where supported.
- Validate input according to the expected format.

## Authentication / Authorization
- Preserve existing authentication mechanisms.
- Enforce authorization at the appropriate boundary.
- Never bypass authorization to fix functional issues.
- Never hardcode credentials.

## Secrets
Never place these in source code:
- Passwords
- API keys
- Access tokens
- Certificates/private keys
- Connection strings containing credentials

Use the project's existing secret-management mechanism.

## Cryptography
- Prefer framework-approved cryptographic libraries.
- Do not invent custom encryption algorithms.
- Do not hardcode encryption keys.
- Do not weaken algorithms or key sizes to resolve compatibility issues.

## Static Analysis
When resolving Sonar/Veracode findings:
1. Fix the root cause.
2. Prefer minimal code changes.
3. Preserve behavior.
4. Do not suppress findings unless explicitly approved.
5. Add/update focused tests.
6. Avoid unrelated refactoring.

## Output
Use:
`CWE -> Root cause -> Minimal remediation -> Test`

Show only relevant code and mention compatibility impact when applicable.
