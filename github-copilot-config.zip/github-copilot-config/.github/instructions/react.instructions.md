---
name: React and TypeScript instructions
description: ReactJS and TypeScript application coding rules
applyTo: '**/*.tsx,**/*.ts,**/*.jsx,**/*.js'
---

# React / TypeScript Instructions

## React
- Follow the existing component structure and conventions.
- Reuse existing components, hooks, services, and utilities.
- Avoid unnecessary state.
- Prefer existing API/service abstractions.
- Do not introduce a new state-management library unless requested.
- Keep components focused.
- Avoid unnecessary re-renders.
- Preserve existing routing and application behavior.

## TypeScript
- Prefer strong typing.
- Avoid `any` unless unavoidable and justified.
- Reuse existing interfaces and types.
- Handle null/undefined explicitly.
- Do not suppress TypeScript errors without addressing the cause.

## UI / Accessibility
- Follow the existing design system.
- Preserve existing accessibility behavior.
- Do not change styling unrelated to the requested task.
- Keep business logic outside presentation components where the existing architecture supports it.
