---
name: .NET and C# instructions
description: Enterprise .NET Core, ASP.NET Core and microservices coding rules
applyTo: '**/*.cs,**/*.csproj,**/*.sln'
---

# .NET / C# Instructions

## Architecture
- Follow the existing solution architecture and project boundaries.
- Reuse existing services, helpers, DTOs, interfaces, middleware, and patterns.
- Keep controllers/endpoints thin.
- Keep business logic in the appropriate service/domain layer.
- Do not introduce a new design pattern unless justified by the existing architecture.
- Do not move business logic between microservices without explicit approval.

## C# / .NET
- Follow existing C# conventions.
- Use dependency injection.
- Use async/await for I/O operations.
- Avoid `.Result`, `.Wait()`, and blocking asynchronous calls.
- Use `CancellationToken` where supported by the existing architecture.
- Respect nullable reference types.
- Keep business logic testable.
- Avoid unnecessary allocations and premature optimization.
- Do not introduce new NuGet packages unless required.

## APIs
- Preserve existing request/response contracts.
- Validate external input.
- Follow existing HTTP status-code conventions.
- Do not expose internal exceptions or implementation details.
- Preserve existing authentication and authorization behavior.

## Microservices
- Respect service boundaries.
- Preserve existing event/message contracts.
- Consider retries, timeouts, idempotency, and transient failures for external calls.
- Do not change message schemas without explicit approval.

## EF Core / Database Access
- Follow existing DbContext/repository patterns.
- Avoid N+1 queries.
- Avoid unnecessary database calls.
- Use `AsNoTracking()` for appropriate read-only queries.
- Prefer projection when only selected fields are required.
- Keep filtering/database operations server-side.
- Never concatenate untrusted input into SQL.
- Do not modify schema/migrations unless explicitly requested.

## Logging / Exceptions
- Follow existing logging conventions.
- Do not log passwords, tokens, secrets, or sensitive business data.
- Do not catch exceptions unless they can be handled meaningfully.
- Preserve existing exception-handling behavior.

## Output
For implementation tasks, keep the response concise:
`Approach -> Files changed -> Validation -> Remaining issue`
