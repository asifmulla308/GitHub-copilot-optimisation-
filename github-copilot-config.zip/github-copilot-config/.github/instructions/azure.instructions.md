---
name: Azure instructions
description: Azure Functions, App Services, Storage, Key Vault, Azure SQL and Application Insights rules
applyTo: '**/*.cs,**/*.json,**/*.bicep,**/*.yml,**/*.yaml'
---

# Azure Instructions

## Services
Existing platform may include:
- Azure Functions
- Azure App Services
- Azure Storage
- Azure SQL
- Azure Key Vault
- Application Insights
- Azure DevOps

## Rules
- Reuse existing Azure architecture and configuration patterns.
- Do not introduce a new Azure service without justification.
- Never hardcode credentials, secrets, tokens, or connection strings.
- Use Key Vault or the project's existing secure configuration mechanism.
- Preserve existing Application Insights telemetry.
- Follow existing environment/configuration conventions.
- Keep development, test, and production configuration separated.

## Azure Functions
- Keep functions focused.
- Avoid unnecessary cold-start overhead.
- Use dependency injection where supported by the existing implementation.
- Handle transient Azure failures appropriately.
- Avoid unnecessary network/database calls.

## Storage / External Services
- Follow existing retry and timeout configuration.
- Handle missing resources gracefully.
- Avoid repeated downloads/uploads where possible.
- Do not expose storage credentials.

## Telemetry
- Use existing telemetry patterns.
- Log actionable information only.
- Never log secrets, authentication tokens, passwords, or sensitive personal/business data.

## Infrastructure
- Do not change production infrastructure based on assumptions.
- Avoid destructive operations unless explicitly requested.
- Explain infrastructure-impacting changes briefly before implementation.
