---
name: Azure DevOps instructions
description: Azure DevOps CI/CD pipeline and deployment rules
applyTo: '**/*.yml,**/*.yaml'
---

# Azure DevOps Instructions

## Pipeline
- Follow the existing pipeline structure.
- Make the smallest required change.
- Do not restructure working pipelines unnecessarily.
- Reuse existing templates, variables, stages, tasks, and service connections.
- Preserve approvals and deployment gates.
- Do not change production deployment behavior unless explicitly requested.

## Security
- Never hardcode passwords, tokens, secrets, certificates, or connection strings.
- Use existing variable groups, secret variables, or service connections.
- Never print secrets in pipeline logs.
- Do not bypass security controls.

## Build / Test
- Preserve existing SDK/runtime versions unless explicitly requested.
- Reuse existing restore, build, test, scan, and artifact steps.
- Do not disable tests or security scans to make a pipeline pass.

## Deployment
- Preserve environment separation.
- Do not bypass approvals or quality gates.
- Keep deployment changes minimal.

## Docker
- Follow the existing Dockerfile/build pattern.
- Avoid unnecessary layers.
- Do not embed credentials.
- Do not change ports/runtime configuration without checking dependent services.

## Troubleshooting
1. Identify the failing stage/task.
2. Read the actual error.
3. Identify the root cause.
4. Make the smallest change.
5. Validate the affected stage.

Do not blindly retry unrelated approaches.
