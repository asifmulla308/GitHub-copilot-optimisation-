---
name: Testing instructions
description: Unit and automated test rules for .NET and frontend tests
applyTo: '**/*Tests.cs,**/*Test.cs,**/*.test.ts,**/*.test.tsx,**/*.spec.ts,**/*.spec.tsx'
---

# Testing Instructions

## General
- Follow the existing test framework and conventions.
- Test behavior, not implementation details.
- Add focused tests for changed business logic.
- Cover success, failure, validation, and important edge cases.
- Reuse existing test helpers, builders, fixtures, and mocking patterns.
- Do not rewrite unrelated tests.
- Do not remove tests merely to make the build pass.

## Bug Fixes
1. Reproduce or represent the failure with a focused test.
2. Implement the minimal fix.
3. Run the relevant test(s).
4. Run broader validation when practical.

## Mocking
- Mock external dependencies, not the class under test.
- Follow existing dependency-injection patterns.
- Do not introduce a new mocking library unnecessarily.

## Output
Use concise reporting:
`Scenario -> Expected -> Result`
