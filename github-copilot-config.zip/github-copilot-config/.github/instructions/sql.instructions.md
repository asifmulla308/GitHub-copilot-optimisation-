---
name: SQL Server instructions
description: SQL Server scripts, queries, stored procedures and database change rules
applyTo: '**/*.sql'
---

# SQL Server Instructions

## General
- Follow existing database naming and formatting conventions.
- Preserve existing schema and object contracts unless explicitly requested.
- Prefer set-based operations.
- Avoid cursors unless clearly required.
- Avoid `SELECT *`.
- Return only required columns.
- Use appropriate joins and predicates.
- Keep filtering close to the database.

## Performance
- Consider execution-plan impact for complex queries.
- Avoid unnecessary table scans and repeated database calls.
- Avoid functions on indexed columns in predicates when they prevent index usage.
- Do not add indexes without understanding existing indexes and workload.

## Security
- Never concatenate untrusted input into SQL.
- Use parameters for application-supplied values.
- Do not expose credentials or connection strings.
- Follow existing permission/security patterns.

## Stored Procedures
- Preserve existing input/output contracts.
- Follow the project's existing error-handling pattern.
- Avoid unnecessary dynamic SQL.
- If dynamic SQL is required, parameterize it safely.

## Scripts / Migrations
- Do not make destructive schema changes unless explicitly requested.
- Consider backward compatibility with currently deployed application versions.
- Make deployment scripts repeatable where practical.
- Handle object existence appropriately.
- Do not modify production data without explicit instruction.

## Output
Show only changed SQL unless a complete script is explicitly requested.
