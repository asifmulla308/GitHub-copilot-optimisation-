# GitHub Copilot Enterprise Coding Instructions

This folder contains repository-level GitHub Copilot instructions optimized for an enterprise .NET Core / Microservices / Azure / ReactJS project.

## Installation

Copy the `.github` folder into the root of your repository.

```text
.github/
├── copilot-instructions.md
└── instructions/
    ├── dotnet.instructions.md
    ├── react.instructions.md
    ├── tests.instructions.md
    ├── azure.instructions.md
    ├── sql.instructions.md
    ├── devops.instructions.md
    └── security-veracode.instructions.md
```

## Design Goals

- Keep global instructions small.
- Apply technology-specific instructions only to relevant files.
- Reduce unnecessary repository exploration and repeated explanations.
- Encourage minimal, production-safe changes.
- Preserve security and quality gates.
- Keep Copilot responses concise without sacrificing correctness.

## Recommended Copilot Workflow

### Simple change

```text
Understand -> Change -> Validate
```

### Complex change

```text
Analyze -> Plan -> Implement -> Test
```

### Bug / pipeline / Veracode issue

```text
Read actual error/finding -> Root cause -> Minimal fix -> Validate
```

## Important

The instructions intentionally do not tell Copilot to hide reasoning or skip required analysis. They optimize the amount of unnecessary context and output while preserving engineering quality.
